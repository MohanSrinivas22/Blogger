
import { useEffect, useState } from "react";
import BlogList from "../../Utils/BlogList";
import { BlogModel } from "../../models/BlogModel";

const HomePage = () => {

    const [blogs, setBlogs] = useState<BlogModel[]>([]);
    const [httpError, setHttpError] = useState(null);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        const url = "http://localhost:8080/blogs"
        const fetchBlogs = async() => {
            const response = await fetch(url);
            if(!response.ok){
                throw new Error("Something went wrong.");
            }
            const responseJson = await response.json();
            setBlogs(responseJson);
            setIsLoading(false);
        };
        fetchBlogs().catch((error: any) => {
            setIsLoading(false);
            setHttpError(error.message);
        });

    },[]);

    return ( 
        <div className="homepage">
            {httpError && <div>{httpError}</div> }
            {isLoading && <div>Loading...</div> }
            {blogs && <BlogList blogs={blogs} />}
        </div> 
    );
}
 
export default HomePage;