import { useState, useEffect } from "react";
import { BlogModel } from "../../models/BlogModel";
import { useParams, useNavigate } from "react-router-dom";

const BlogDetails = () => {

    const [blog, setBlog] = useState<BlogModel>();
    const [httpError, setHttpError] = useState(null);
    const [isLoading, setIsLoading] = useState(true);

    const navigate = useNavigate();

    const { id } = useParams(); 
    const url = "http://localhost:8080/blogs/" + id;

    useEffect(() => {
        const fetchBlog = async() => {
            const response = await fetch(url);
            if(!response.ok){
                throw new Error("Something went wrong.");
            }
            const responseJson = await response.json();
            setBlog(responseJson);
            setIsLoading(false);
        };
        fetchBlog().catch((error: any) => {
            setIsLoading(false);
            setHttpError(error.message);
        });
    },[url]);

    const handleDelete = () => {
        fetch("http://localhost:8080/delete/" + blog?.id, {
            method : "DELETE"
        }).then(() => {
            navigate("/");
        })
    }

    return ( 
        <div className="blog-details">
            {isLoading && <div>Loading...</div>}
            {httpError && <div>{httpError}</div>}
            {blog && (
                <article>
                    <h2>{blog.title}</h2>
                    <p>Written by - {blog.author}</p>
                    <div>{blog.body}</div>
                    <button className="delete btn" onClick={handleDelete}>delete</button>
                </article>
            )}
        </div>
     );
}
 
export default BlogDetails;