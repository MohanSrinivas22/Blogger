import { useState} from "react";
import { useNavigate } from 'react-router-dom';

const CreatePage = () => {

    const [id, setId] = useState(0);
    const [title, setTitle] = useState("");
    const [body, setBody] = useState("");
    const [author, setAuthor] = useState("");
    const [isLoading, setIsLoading] = useState(false);

    const navigate = useNavigate();

    const handleSubmit = (e: any) => {
        e.preventDefault();
        const newBlog = {
            "id" : id,
            "title" : title,
            "body" : body,
            "author" : author
        }
        setIsLoading(true);
        fetch(
            "http://localhost:8080/add", {
                method: "POST",
                headers: {"Content-Type": "application/json"},
                body: JSON.stringify(newBlog)
            }).then(() => {
                console.log('new blog added');
                setIsLoading(false);
                navigate("/")
            })
    }

    return ( 
        <div className="create">
            <h2>Add a New Blog</h2>
            <form onSubmit={handleSubmit}>
                <label>Blog Id:</label>
                <input 
                    type="text"
                    value={id}
                    onChange={(e) => setId(Number(e.target.value))}
                    required
                />
                <label>Blog Title:</label>
                <input 
                    type="text" 
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    required
                />
                <label>Blog Body:</label>
                <textarea 
                    value={body}
                    rows={5}
                    onChange={(e) => setBody(e.target.value)}
                    required
                >
                </textarea>
                <label>Blog Author:</label>
                <input 
                    type="text" 
                    value={author}
                    onChange={(e) => setAuthor(e.target.value)}
                    required
                />
                {!isLoading && <button>Add Blog</button>}
                {isLoading && <button disabled>Adding Blog...</button>}
            </form>
        </div>
    );
}
 
export default CreatePage;