import React from "react";
import "./App.css";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import HomePage from "./layouts/HomePage/HomePage";
import Footer from "./Utils/footer";
import { Navbar } from "./Utils/Navbar";
import CreatePage from "./layouts/CreatePage/CreatePage";
import BlogDetails from "./layouts/HomePage/BlogDetails";

function App() {
  return (
    <Router>
      <div className="App">
        <Navbar />
        <div className="content">
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/create" element={<CreatePage />} />
            <Route path="/blogs/:id" element={<BlogDetails />}/>
          </Routes>
        </div>
        <Footer />
      </div>
    </Router>
  );
}
export default App;
