export class BlogModel{
    blogs: any;
    constructor(
        public title: String,
        public body: String,
        public author: String,
        public id: number
    ){}
}