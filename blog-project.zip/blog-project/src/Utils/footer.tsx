import { Link } from "react-router-dom";
const Footer = () => {
    return ( 
        <footer className="footer">
            <p>@ All Copyrights Reserved 2024-26</p>
            <div className="nav-links">
                <Link to="/">Home</Link>
                <Link to="/create">New Blog</Link>
            </div>
        </footer>
     );
}
 
export default Footer;