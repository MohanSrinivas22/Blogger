import { Link, useNavigate } from "react-router-dom";
import { BlogModel } from "../models/BlogModel";

const BlogList: React.FC<{blogs: BlogModel[]}> = (props) => {

    const navigate = useNavigate();
    const handleDelete = (id: number) => {
        fetch("http://localhost:8080/delete/" + id,{
            method: "DELETE"
        }).then(() =>{
            navigate("/")
        })
    }

    return ( 
        <div className="blog-list">
            {props.blogs.map((blog: BlogModel) => (
                <div className="blog-preview" key={blog.id}>
                    <Link to={`/blogs/${blog.id}`}>
                        <h2>{blog.title}</h2>
                        <p>Written by {blog.author}</p>
                        <button 
                            className="delete btn"
                            onClick={() => handleDelete(blog.id)}
                        >
                            Delete
                        </button>
                    </Link>
                </div>
            ))}
        </div>
     );
}
 
export default BlogList;